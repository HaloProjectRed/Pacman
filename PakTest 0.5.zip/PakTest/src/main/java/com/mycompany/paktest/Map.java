/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.util.List;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JComponent;

/**
 *
 * @author desenv
 */
public class Map extends JComponent implements Runnable{
   public List<Power> powers;
   public List<Eatable> eatables;
   public List<Wall>walls;
   public PacChief pac;
   
   public Map(){
        setSize(800, 580);
        eatables = new ArrayList<>();
        powers = new ArrayList<>();
        walls = new ArrayList();
   }

   
    @Override
    public void run() {
        
    }
    
    
}
