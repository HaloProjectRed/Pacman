/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author desenv
 */
public class Game extends JFrame {
    private Map map;
    
    public Game(){
        super("PakMano");
        Dimension d = new Dimension(800, 600);
        setSize(d);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setFocusable(true);
        setVisible(true);
        
        
    }
    
}
