/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.List;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Timer;
import javax.swing.JComponent;

/**
 *
 * @author desenv
 */
public class Map extends JComponent implements Runnable{
   public List<Power> powers;
   public List<Eatable> eatables;
   public List<Wall>walls;
   public List<Ghost>ghosts;
   public PacChief pac;
   Timer tm = new Timer(4, this);
   
   public Map(){
       PacChief pac= new PacChief();
        setSize(800, 580);
        eatables = new ArrayList<>();
        powers = new ArrayList<>();
        walls = new ArrayList();
        ghosts=new ArrayList();
   }

   
    @Override
    public void run() {
        
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);
        
        Graphics2D g2=(Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
        
        pac.draw(g);
        for(Wall w: this.walls){
        }
        tm.start();
    }
    
    
}
