/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.Timer;

/**
 *
 * @author desenv
 */
public class Map extends JComponent implements ActionListener{
   public List<Power> powers;
   public List<Eatable> eatables;
   public List<Wall>walls;
   public List<Ghost>ghosts;
   public PacChief pac;
   Timer tm = new Timer(4, this);
   
   public Map(){
        setSize(800, 600);
        eatables = new ArrayList<>();
        powers = new ArrayList<>();
        walls = new ArrayList<>();
        ghosts=new ArrayList<>();
        PacChief pacC;
        pacC = new PacChief();
        
       // !!BLOCKS!! //
                           
        // bloco cima
        Wall b1 = new Wall();
        b1.width = getWidth();
        b1.height = 10;
        b1.x = 0;
        b1.y = 0;
               
        walls.add(b1);
        
        // bloco baixo
        Wall b2 = new Wall();
        b2.width = getWidth();
        b2.height = 10;
        b2.x = 0;
        b2.y = 480;
               
        walls.add(b2);
        
        //bloco lado esquerdo
        Wall b3 = new Wall();
        b3.width = 10;
        b3.height = 490;
        b3.x = 0;
        b3.y = 0;
                
        walls.add (b3);
        
        //bloco lado direito
        Wall b4 = new Wall();
        b4.width = 10;
        b4.height = 490;
        b4.x = 790;
        b4.y = 0;
              
        walls.add (b4);
                      
        // Blocos lado esquerdo 1
        for (int ble1=0; ble1<3; ble1++) {
        Wall b5 = new Wall();
        b5.x = 10;
        b5.y = 120+ble1*120;
        b5.width = 50;
        b5.height = 10;
        
        walls.add(b5);
        }
        
        // Blocos lado direito 1
        for(int bld1=0;bld1<3;bld1++){
        Wall b6 = new Wall();
        b6.x = 740;
        b6.y = 120+bld1*120;
        b6.width = 50;
        b6.height = 10;
        
        walls.add(b6);
        }
                      
        // Blocos lado esquerdo 2
        for(int ble2=0;ble2<4;ble2++){
        Wall b7 = new Wall();
        b7.x = 60;
        b7.y = 60+ble2*120;
        b7.width = 50;
        b7.height = 10;
        
        walls.add(b7);
        }
        
        // Blocos lado direito 2       
        for(int bld2=0;bld2<4;bld2++){
        
        Wall b8 = new Wall();
        b8.x = 690;
        b8.y = 60+bld2*120; 
        b8.width = 50;
        b8.height = 10;
                
        walls.add(b8);  
        }               
           
        // Blocos lado esquerdo 3
        for(int ble3=0;ble3<3;ble3++){
        Wall b9 = new Wall();
        b9.x =  115;
        b9.y =  120 +ble3*120;
        b9.width = 60;
        b9.height = 10;      
                
        walls.add(b9);
                }   
        
        //Blocos lado direito 3
        for(int bld3=0;bld3<3;bld3++){
        Wall b10 = new Wall();
        b10.x = 625;
        b10.y = 120 +bld3*120;
        b10.width = 62;
        b10.height =  10;       
        walls.add(b10);
}
                
         //Blocos repetidos 4 lado esquerdo
        for(int ble4=0;ble4<4;ble4++){
        Wall b11 = new Wall();        
        b11.x = 160;
        b11.y = 60+ble4*120;
        b11.width = 15;
        b11.height = 60;      
        walls.add(b11);
        }        
        
         //Blocos repetidos 4 lado direito
        for(int bld4=0;bld4<4;bld4++){        
        Wall b12 = new Wall();
        b12.x = 625;
        b12.y = 60+bld4*120;
        b12.width = 15;
        b12.height = 60;
        walls.add(b12);  
}
        
        //Bloco repetidos 5 lado esquerdo
        for(int ble5=0;ble5<4;ble5++){
        Wall b13 = new Wall();
        b13.x = 225;
        b13.y = 60+ble5*120;
        b13.width = 25;
        b13.height = 10;
        walls.add(b13);       
}        
        
         //Blocos repetidos 5 lado direito
        for(int bld5=0;bld5<4;bld5++){
        Wall b14 = new Wall();
        b14.x = 550;
        b14.y = 60+bld5*120;
        b14.width = 25;
        b14.height = 10;
        walls.add(b14);
}
 
        
        //Blocos repetidos 6 lado esquerdo
        for(int ble6=0;ble6<3;ble6++){
        Wall b15 = new Wall();
        b15.x = 225;
        b15.y = 120+ble6*120;
        b15.width = 90;
        b15.height = 10;
        walls.add(b15);       
}
        
        //Blocos repetidos 6 lado direito
        for(int bld6=0;bld6<3;bld6++){
        Wall b16 = new Wall();
        b16.x = 485;
        b16.y = 120+bld6*120;
        b16.width = 90;
        b16.height = 10;
        walls.add(b16);         
}
        
        //Blocos repetidos 7 lado esquerdo
        for(int ble7=0;ble7<4;ble7++){    
        Wall b17 = new Wall();   
        b17.x = 300;
        b17.y = 10+ble7*120;
        b17.width = 15;
        b17.height = 60;       
        walls.add(b17); 
}
 
         //Blocos repetidos 7 lado direito 
        for(int bld7=0;bld7<4;bld7++){
        Wall b18 = new Wall(); 
        b18.x = 485;
        b18.y = 10+bld7*120;
        b18.width = 15;
        b18.height = 60;      
        walls.add(b18); 
}

         //Blocos repetidos centro 
        for(int blc=0;blc<7;blc++){
        Wall b19 = new Wall(); 
        b19.x = 365;
        b19.y = 60+blc*60;
        b19.width = 70;
        b19.height = 10;
        walls.add(b19);         
}
        
         //Blocos repetidos centro lado
        for(int blcl=0;blcl<2;blcl++){
        Wall b20 = new Wall(); 
        b20.x = 365+blcl*60;
        b20.y = 180;
        b20.width = 10;
        b20.height = 60;  
        walls.add(b20);         

     }  
        
             // !FOODS! //
             
              // !FOOD BAIXO! // 
        //Food baixo esquerdo 1     
        for(int fbe1=0; fbe1<6; fbe1++){     
        Eatable f = new Eatable(); 
        f.x = 25+fbe1*46;
        f.y = 392;
        f.width = 18;
        f.height = 6;
                
        eatables.add(f);                
        }
        
        //Food baixo esquerdo 2
        for(int fbe2=0;fbe2<3;fbe2++){        
        Eatable f0 = new Eatable(); 
        f0.x = 25+fbe2*48;
        f0.y = 455;
        f0.width = 18;
        f0.height = 6;
        eatables.add(f0);
        }
        
        //Food baixo esquerdo 3
        for(int fbe2=0;fbe2<5;fbe2++){
        Eatable f1 = new Eatable(); 
        f1.x = 189+fbe2*38;
        f1.y = 455;
        f1.width = 18;
        f1.height = 6;
        eatables.add(f1);  
        }
        
        //Food baixo direito 1
        for(int fbd1=0; fbd1<6; fbd1++){
        Eatable f2 = new Eatable(); 
        f2.x = 524+fbd1*46;
        f2.y = 392;
        f2.width = 18;
        f2.height = 6;
        eatables.add(f2);  
        }
        
               
        //Food baixo direito 2
        for(int fbd2=0; fbd2<3; fbd2++){
        Eatable f3 = new Eatable(); 
        f3.x = 659+fbd2*46;
        f3.y = 455;
        f3.width = 18;
        f3.height = 6;
        eatables.add(f3);  
        }
        
        //Food baixo direito 3
        for(int fbd3=0;fbd3<5;fbd3++){
        Eatable f4 = new Eatable(); 
        f4.x = 442+fbd3*38;
        f4.y = 455;
        f4.width = 18;
        f4.height = 6;
        eatables.add(f4); 
        }
        
                 
           // !FOOD CENTRO! //
        
        //Food centro esquerdo 1
        for(int fbce1=0; fbce1<6; fbce1++){
        Eatable f5 = new Eatable(); 
        f5.x = 25+fbce1*46;
        f5.y = 152;
        f5.width = 18;
        f5.height = 6;
        eatables.add(f5);  
        }
        
         //Food centro direito 1
        for(int fbcd1=0; fbcd1<6; fbcd1++){
        Eatable f6 = new Eatable(); 
        f6.x = 524+fbcd1*46;
        f6.y = 152;
        f6.width = 18;
        f6.height = 6;
        eatables.add(f6);  
        }
        
        //Food centro esquerdo 2
        for(int fbce2=0;fbce2<3;fbce2++){
        Eatable f7 = new Eatable(); 
        f7.x = 25+fbce2*48; 
        f7.y = 212;
        f7.width = 18;
        f7.height = 6;
        eatables.add(f7);  
        }
        
        //Food centro direito 2
        for(int fbcd2=0;fbcd2<3;fbcd2++){
        Eatable f8 = new Eatable(); 
        f8.x = 658+fbcd2*48;
        f8.y = 212;
        f8.width = 18;
        f8.height = 6;
        eatables.add(f8);  
        }
        
        //Food centro esquerdo 3
        for(int fbce3=0;fbce3<4;fbce3++){        
        Eatable f9 = new Eatable(); 
        f9.x = 189+fbce3*43; 
        f9.y = 212;
        f9.width = 18;
        f9.height = 6;
        eatables.add(f9);  
        }
        
        //Food centro direito 3
        for(int fbcd3=0;fbcd3<4;fbcd3++){
        Eatable f10 = new Eatable(); 
        f10.x = 467+fbcd3*43;
        f10.y = 212;
        f10.width = 18;
        f10.height = 6;
        eatables.add(f10);  
        }
        
        //Food centro esquerdo 4
        for(int fbce4=0; fbce4<6; fbce4++){ 
        Eatable f11 = new Eatable(); 
        f11.x = 25+fbce4*46; 
        f11.y = 272;
        f11.width = 18;
        f11.height = 6;
        eatables.add(f11);  
        }
        
        //Food centro direito 4
        for(int fbcd4=0; fbcd4<6; fbcd4++){ 
        Eatable f12 = new Eatable(); 
        f12.x = 524+fbcd4*46; 
        f12.y = 272;
        f12.width = 18;
        f12.height = 6;
        eatables.add(f12);  
        }
        
        //Food centro esquerdo 5
        for(int fbce2=0;fbce2<3;fbce2++){
        Eatable f13 = new Eatable(); 
        f13.x = 25+fbce2*48;
        f13.y = 332;
        f13.width = 18;
        f13.height = 6;
        eatables.add(f13);  
        }
        
        //Food centro direito 5
        for(int fbcd2=0;fbcd2<3;fbcd2++){
        Eatable f14 = new Eatable(); 
        f14.x = 658+fbcd2*48;
        f14.y = 332;
        f14.width = 18;
        f14.height = 6;
        eatables.add(f14);  
        }
        
        //Food centro esquerdo 6
        for(int fbce3=0;fbce3<5;fbce3++){
        Eatable f15 = new Eatable(); 
        f15.x = 189+fbce3*43;
        f15.y = 332;
        f15.width = 18;
        f15.height = 6;
        eatables.add(f15);  
        } 
        
        //Food centro direito 6
        for(int fbcd3=0;fbcd3<5;fbcd3++){
        Eatable f16 = new Eatable(); 
        f16.x = 424+fbcd3*43;
        f16.y = 332;
        f16.width = 18;
        f16.height = 6;
        eatables.add(f16);  
        }   
        
           // !FOOD TOPO! //
        
        //Food topo esquerdo 1
        for(int fbte1=0; fbte1<6; fbte1++){
        Eatable f17 = new Eatable(); 
        f17.x = 25+fbte1*46;
        f17.y = 32;
        f17.width = 18;
        f17.height = 6;
        eatables.add(f17);  
        }
        
        //Food topo esquerdo 2
        for(int fbte2=0;fbte2<3;fbte2++){
        Eatable f18 = new Eatable(); 
        f18.x = 25+fbte2*48; 
        f18.y = 90;
        f18.width = 18;
        f18.height = 6;
        eatables.add(f18);  
        }
           
        //Food topo esquerdo 3
        for(int fbte3=0;fbte3<5;fbte3++){        
        Eatable f19 = new Eatable(); 
        f19.x = 189+fbte3*43; 
        f19.y = 90;
        f19.width = 18;
        f19.height = 6;
        eatables.add(f19);  
        }
        
        //Food topo direito 1
        for(int fbtd1=0; fbtd1<6; fbtd1++){
        Eatable f20 = new Eatable(); 
        f20.x = 524+fbtd1*46;
        f20.y = 32;
        f20.width = 18;
        f20.height = 6;
        eatables.add(f20);  
        }
        
        //Food topo direito 2
        for(int fbtd2=0;fbtd2<3;fbtd2++){
        Eatable f21 = new Eatable(); 
        f21.x = 658+fbtd2*48; 
        f21.y = 90;
        f21.width = 18;
        f21.height = 6;
        eatables.add(f21);  
        }
        
        //Food topo direito 3
        for(int fbtd3=0;fbtd3<5;fbtd3++){        
        Eatable f22 = new Eatable(); 
        f22.x = 424+fbtd3*43; 
        f22.y = 90;
        f22.width = 18;
        f22.height = 6;
        eatables.add(f22);  
        }
        
             // !FOOD MEIO! //
             
        //Food meio pequeno 1     
        for(int fbmp1=0;fbmp1<2;fbmp1++){        
        Eatable f23 = new Eatable(); 
        f23.x = 328+fbmp1*125; 
        f23.y = 32;
        f23.width = 18;
        f23.height = 6;
        eatables.add(f23);  
        }
        
        //Food meio grande 1
        Eatable f24 = new Eatable(); 
        f24.x = 380; 
        f24.y = 32;
        f24.width = 40;
        f24.height = 6;
        eatables.add(f24);  
        
        //Food meio pequeno 2
        for(int fbmp2=0;fbmp2<2;fbmp2++){        
        Eatable f25 = new Eatable(); 
        f25.x = 328+fbmp2*125; 
        f25.y = 152;
        f25.width = 18;
        f25.height = 6;
        eatables.add(f25);  
        }
        
        //Food meio grande 2
        Eatable f26 = new Eatable(); 
        f26.x = 380; 
        f26.y = 152;
        f26.width = 40;
        f26.height = 6;
        eatables.add(f26); 
        
        //Food meio pequeno 3
        for(int fbmp3=0;fbmp3<2;fbmp3++){        
        Eatable f27 = new Eatable(); 
        f27.x = 328+fbmp3*125; 
        f27.y = 272;
        f27.width = 18;
        f27.height = 6;
        eatables.add(f27);  
        }
        
        //Food meio grande 3
        Eatable f28 = new Eatable(); 
        f28.x = 380; 
        f28.y = 272;
        f28.width = 40;
        f28.height = 6;
        eatables.add(f28); 
        
        //Food meio grande 4
        Eatable f29 = new Eatable(); 
        f29.x = 380; 
        f29.y = 392;
        f29.width = 40;
        f29.height = 6;
        eatables.add(f29); 
        
        //Food meio pequeno 4
        for(int fbmp4=0;fbmp4<2;fbmp4++){        
        Eatable f30 = new Eatable(); 
        f30.x = 328+fbmp4*125; 
        f30.y = 392;
        f30.width = 18;
        f30.height = 6;
        eatables.add(f30);  
        }
        
             // !BOOSTS! //
        for(int bs=0;bs<2;bs++){        
        Power bo1 = new Power(); 
        bo1.x = 25+bs*734; 
        bo1.y = 58;
        powers.add(bo1);  
        }  
        
        for(int bi=0;bi<2;bi++){        
        Power bo2 = new Power(); 
        bo2.x = 25+bi*734; 
        bo2.y = 418;
        powers.add(bo2);  
        }    
        
             // !GHOSTS! //      
        
        Ghost g1= new Ghost();
        g1.color = new Color(104,249,137);
        g1.y = 193;
        ghosts.add(g1);
        
        Ghost g2= new Ghost();
        g2.color = (Color.YELLOW);
        g2.y = 193;
        ghosts.add(g2);
        
        Ghost g3= new Ghost();
        g3.color = new Color(252, 3, 23);
        g3.y = 193;
        ghosts.add(g3);
        
        Ghost g4= new Ghost();
        g4.color = new Color(219, 3, 252);
        g4.y = 193;
        ghosts.add(g4);
        
        } 

   
    
    @Override
    public void paint(Graphics g) {
        super.paint(g); 
        
          // fundo
        g.setColor(new Color(63, 48, 191));
        g.fillRect(0, 0, getWidth(), getHeight());
        
        // area info
        g.setColor(Color.BLACK);
        g.fillRect(0, 495, getWidth(), 100);
        
        // area info 2
        g.setColor(new Color(54, 141, 35));
        g.fillRect(0, 505, getWidth(), 30);
        
        /*// vidas
        for(int i=0;i<this.pac.live;i++){
        g.fillRect(20+i*25, 540, 15, 15);
        }
        
        // pontuacao
        g.setFont(new Font("arial", Font.BOLD, 25));
        g.setColor(Color.BLACK);
        g.drawString(String.valueOf(this.pac.score), 450, 528);
        */
        
       
        
         
        // desenhar os blocos
        for(Wall b: this.walls){
            b.draw(g);
        }     
        
       // !!FOODS!! //
       for (Eatable f: this.eatables){
        f.draw(g);   
       } 
       
       // !!BOOSTS!! //
       for (Power bo: this.powers){
        bo.draw(g);
       }
       
       pac.draw(g);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       repaint();
    }

    
    
    
}
