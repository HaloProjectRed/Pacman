/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author desenv
 */
public class PacChief extends Will {
    int width, height, x, y,velx, vely, angA;
    Color color;
    
    public PacChief(){
        this.width= 30;
        this.height=30;
        this.color = new Color(237, 235, 0);
        this.x=380;
        this.y=428;
        this.velx=0;
        this.vely=0;
        this.angA=30;
    }

    /**
     *
     * @param g
     */
    @Override
    public void  draw(Graphics g){   
     g.setColor(color); 
     g.fillArc(x, y, width, height, angA, 300);
    }
   
   
}

