/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author desenv
 */
public class Ghost extends Will {
    public boolean attack;
    public Ghost(){
        this.x=385;
        this.y=135;
        this.width=40;
        this.height=40;
        this.attack=true;
        this.velx=0;
        this.vely=0;
        
    }
    @Override
    public void draw(Graphics g){
        //Ghost
        g.setColor(color);
        g.fillArc(x, y, width, height, 0, 360);
        g.fillRect(x, y + 20, 40, 20);
        
        //Olhos
        //Esquerdo
        g.setColor(Color.WHITE);
        g.fillArc(x + 10, y + 12, 10, 10, 135, 180);
        //Direito
        g.setColor(Color.WHITE);
        g.fillArc(x + 22, y + 12, 10, 10, 225, 175);
        
    }
    
}
