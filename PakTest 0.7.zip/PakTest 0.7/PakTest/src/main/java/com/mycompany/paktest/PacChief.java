/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.paktest;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author desenv
 */
public class PacChief extends Will {
    int killer, score, live, xo, yo, angA;
    
    public PacChief(){
        this.width= 30;
        this.height=30;
        this.color= new Color(237, 235, 0);
        this.x=380;
        this.y=428;
        this.velx=0;
        this.vely=0;
        this.angA=30;
        this.xo=16;
        this.yo=6;
    }
    public void  draw(Graphics g){
     
    }
    public void move(){
        
    }
   
}

